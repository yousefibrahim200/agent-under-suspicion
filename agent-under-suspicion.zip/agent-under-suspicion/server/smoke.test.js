'use strict';
process.env.DURATION_SCALE = '0.1';
const assert = require('assert');
const { io: connect } = require('socket.io-client');
const { server } = require('./index');

const emit = (s, ev, d) => new Promise((r) => s.emit(ev, d, r));
function client(port) {
  const s = connect(`http://localhost:${port}`, { transports: ['websocket'], forceNew: true });
  s.latest = null;
  s.on('state', (st) => { s.latest = st; });
  return s;
}
const until = async (fn, ms = 8000) => { const t = Date.now(); while (Date.now() - t < ms) { const v = fn(); if (v) return v; await new Promise((r) => setTimeout(r, 25)); } throw new Error('timeout: ' + fn); };
const phase = (c, p) => until(() => c.latest && c.latest.phase === p && c.latest);

server.listen(0, async () => {
  const port = server.address().port;
  try {
    const tv = client(port), a = client(port), b = client(port), c = client(port);
    const t = await emit(tv, 'room:create', { mode: 'tv' });
    assert(/^[A-Z2-9]{5}$/.test(t.code), '5-char code');
    const code = t.code; // phones join the room the TV is hosting; first joiner becomes host
    const ra = await emit(a, 'room:join', { code, name: 'Host' });
    assert(ra.ok);
    const rb = await emit(b, 'room:join', { code, name: 'B' });
    const rc = await emit(c, 'room:join', { code, name: 'C' });
    assert(rb.ok && rc.ok, 'joined');
    assert.strictEqual((await emit(client(port), 'room:join', { code: 'ZZZZZ', name: 'x' })).error !== undefined, true, 'bad code rejected');

    assert((await phase(tv, 'LOBBY')).isTv);
    assert.strictEqual((await until(() => tv.latest.players.length === 3 && tv.latest)).players.length, 3, 'TV lists players');

    // lobby refresh: seat must survive a quick drop
    c.disconnect(); await new Promise((r) => setTimeout(r, 200));
    const c2 = client(port); await until(() => c2.connected);
    assert((await emit(c2, 'session:resume', { token: rc.token })).ok, 'lobby resume keeps seat');
    Object.defineProperty(c, 'latest', { get: () => c2.latest }); c.emit = c2.emit.bind(c2);
    a.emit('lobby:settings', { rounds: 1, deckId: 'family' });
    a.emit('game:start');
    const all = [a, b, c];
    await Promise.all(all.map((x) => phase(x, 'PROMPT')));
    const views = all.map((x) => x.latest);
    const agents = views.filter((v) => v.youAreAgent);
    assert.strictEqual(agents.length, 1, 'exactly one agent');
    assert.strictEqual(agents[0].question, null, 'AGENT NEVER RECEIVES THE QUESTION');
    views.filter((v) => !v.youAreAgent).forEach((v) => assert(v.question, 'others see question'));

    await Promise.all(all.map((x) => phase(x, 'ANSWER')));
    // reconnect test: b drops mid-round and resumes with its token
    const before = b.latest.youId;
    b.disconnect();
    const b2 = client(port);
    await until(() => b2.connected);
    const res = await emit(b2, 'session:resume', { token: rb.token });
    assert(res.ok && res.playerId === before, 'resumed same player');
    await until(() => b2.latest && b2.latest.phase === 'ANSWER');
    assert.strictEqual(b2.latest.youId, before);

    [a, b2, c].forEach((x, i) => x.emit('answer:submit', { text: 'answer ' + i + ' <b>x</b>' }));
    const deb = await phase(a, 'DEBATE');
    assert.strictEqual(tv.latest.question, null, 'TV never shows question during play');
    assert.strictEqual(deb.cards.length, 3);
    assert(deb.cards.every((k) => k.authorId === undefined), 'authors hidden during debate');
    assert(!deb.cards.some((k) => /[<>]/.test(k.text)), 'html stripped');

    const vote = await phase(a, 'VOTE');
    const ids = vote.players.map((p) => p.id);
    [a, b2, c].forEach((x) => x.emit('vote:cast', { targetId: ids.find((i) => i !== x.latest.youId) }));
    a.emit('vote:cast', { targetId: a.latest.youId }); // self-vote must be ignored
    const rev = await phase(a, 'REVEAL');
    assert(rev.result && rev.result.agentId, 'result present');
    assert(rev.cards.every((k) => k.authorId), 'authors revealed');
    assert(rev.question, 'question public after reveal');
    assert(tv.latest.question === null || tv.latest.phase !== 'DEBATE', 'TV hides question until reveal');
    await phase(tv, 'REVEAL'); assert(tv.latest.question, 'TV shows question at reveal');

    const fin = await phase(a, 'FINAL');
    assert(fin.recap && fin.recap.mvpId, 'recap with MVP');
    console.log('PASS — full game incl. reconnect, secrecy, scoring, recap');
    process.exit(0);
  } catch (e) { console.error('FAIL', e.message); process.exit(1); }
});
