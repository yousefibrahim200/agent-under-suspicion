'use strict';
const crypto = require('crypto');
const { resolveQuestions } = require('./decks');

/**
 * @typedef {'LOBBY'|'PROMPT'|'ANSWER'|'DEBATE'|'VOTE'|'REVEAL'|'SCOREBOARD'|'FINAL'} Phase
 * @typedef {{id:string,name:string,avatar:string,color:string,score:number,token:string,socketId:string|null,
 *   connected:boolean,isBot:boolean,userId:string|null,stats:{agentRounds:number,escapes:number,correctVotes:number,votes:number}}} Player
 * @typedef {{id:number,text:string,authorId:string,laughs:number,round:number}} Card
 */

const MIN_PLAYERS = 3;
const MAX_PLAYERS = 10;
const SCALE = Number(process.env.DURATION_SCALE || 1);
const DURATIONS = { PROMPT: 6, ANSWER: 45, DEBATE: 60, VOTE: 30, REVEAL: 10, SCOREBOARD: 30 };
const PHASE_ORDER = ['LOBBY', 'PROMPT', 'ANSWER', 'DEBATE', 'VOTE', 'REVEAL', 'SCOREBOARD', 'FINAL'];
const POINTS = { agentEscapes: 200, correctVote: 100 };
const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // no 0/O/1/I
const BOT_NAMES = ['الجدة هدى', 'الخال أحمد', 'الروبوت زكي', 'سارة الذكية', 'الماكر علي', 'عمو سمير'];
const BOT_ANSWERS = ['أكيد الملوخية بالفراخ من غير كلام!', 'هسافر وأرتاح شوية.', 'موقف مضحك لسه فاكره لحد دلوقتي.', 'حاجة بسيطة وجميلة.', 'ده سؤال صعب بصراحة!'];

const clean = (s, max) => String(s ?? '').replace(/[\u0000-\u001f<>]/g, '').trim().slice(0, max);
const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
const shuffle = (arr) => { const a = [...arr]; for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
const newId = () => crypto.randomBytes(8).toString('hex');

function makeCode(taken) {
  for (;;) {
    let c = '';
    for (let i = 0; i < 5; i++) c += ALPHABET[crypto.randomInt(ALPHABET.length)];
    if (!taken.has(c)) return c;
  }
}

class Room {
  /** @param {string} code @param {{broadcast:(r:Room)=>void, fx:(r:Room,ev:string,data:any)=>void}} hooks */
  constructor(code, hooks) {
    this.code = code;
    this.hooks = hooks;
    /** @type {Map<string,Player>} */ this.players = new Map();
    this.hostId = null;
    this.settings = { deckId: 'family', rounds: 5, customQuestions: [] };
    /** @type {Phase} */ this.phase = 'LOBBY';
    this.round = 0;
    this.deadline = null;
    this.timer = null;
    this.botTimers = [];
    this.agentId = null;
    this.question = null;
    this.usedQuestions = new Set();
    this.pastAgents = new Set();
    this.answers = new Map();
    this.votes = new Map();
    /** @type {Card[]} */ this.cards = [];
    /** @type {Card[]} */ this.cardHistory = [];
    this.result = null;
    this.recap = null;
    this.chat = [];
    this.touched = Date.now();
  }

  // ---------- membership ----------
  humans() { return [...this.players.values()].filter((p) => !p.isBot); }
  active() { return [...this.players.values()].filter((p) => p.isBot || p.connected); }
  changed() { this.touched = Date.now(); this.hooks.broadcast(this); }

  addPlayer({ name, avatar, color, userId = null, isBot = false }) {
    if (this.players.size >= MAX_PLAYERS) throw new Error('الغرفة ممتلئة');
    if (this.phase !== 'LOBBY' && !isBot) throw new Error('اللعبة بدأت بالفعل');
    const p = { id: newId(), name: clean(name, 16) || 'لاعب', avatar: this.safeAvatar(avatar), color: clean(color, 9) || '#a855f7',
      score: 0, token: newId() + newId(), socketId: null, connected: !isBot, isBot, userId,
      stats: { agentRounds: 0, escapes: 0, correctVotes: 0, votes: 0 } };
    this.players.set(p.id, p);
    if (!this.hostId && !isBot) this.hostId = p.id;
    this.changed();
    return p;
  }

  safeAvatar(a) {
    a = String(a ?? '');
    if (a.startsWith('data:image/jpeg;base64,') && a.length < 30000 && /^[A-Za-z0-9+/=,:;a-z-]+$/.test(a)) return a;
    return clean(a, 4) || '🕵️';
  }

  setConnected(pid, connected, socketId = null) {
    const p = this.players.get(pid);
    if (!p) return;
    p.connected = connected;
    p.socketId = connected ? socketId : null;
    if (!connected) {
      // In the lobby a seat is only freed after a grace period, so a refresh or brief signal loss keeps your place.
      if (this.phase === 'LOBBY') setTimeout(() => {
        const q = this.players.get(pid);
        if (q && !q.connected && this.phase === 'LOBBY') { this.players.delete(pid); this.migrateHost(); this.changed(); }
      }, 30000).unref?.();
      this.migrateHost();
    } else if (!this.hostId) this.hostId = pid;
    this.changed();
    this.checkCompletion();
  }

  migrateHost() {
    const h = this.players.get(this.hostId);
    if (h && h.connected) return;
    const next = this.humans().find((p) => p.connected);
    this.hostId = next ? next.id : this.hostId;
  }

  isHost(pid) { return pid && pid === this.hostId; }

  // ---------- state machine ----------
  setPhase(phase) {
    clearTimeout(this.timer);
    this.botTimers.forEach(clearTimeout);
    this.botTimers = [];
    this.phase = phase;
    const d = DURATIONS[phase];
    this.duration = d ? d * 1000 * SCALE : 0;
    this.deadline = d ? Date.now() + this.duration : null;
    if (d) this.timer = setTimeout(() => this.advance(), d * 1000 * SCALE);
    if (phase === 'ANSWER') this.scheduleBots('answer');
    if (phase === 'VOTE') this.scheduleBots('vote');
    this.changed();
  }

  advance() {
    switch (this.phase) {
      case 'PROMPT': return this.setPhase('ANSWER');
      case 'ANSWER': this.buildCards(); return this.setPhase('DEBATE');
      case 'DEBATE': return this.setPhase('VOTE');
      case 'VOTE': this.score(); return this.setPhase('REVEAL');
      case 'REVEAL': return this.setPhase('SCOREBOARD');
      case 'SCOREBOARD': return this.round >= this.settings.rounds ? this.finish() : this.nextRound();
      default: return undefined;
    }
  }

  startGame(pid) {
    if (!this.isHost(pid) || this.phase !== 'LOBBY') return 'not allowed';
    if (this.active().length < MIN_PLAYERS) return 'نحتاج 3 لاعبين على الأقل';
    this.round = 0;
    this.pastAgents.clear();
    this.usedQuestions.clear();
    this.cardHistory = [];
    this.recap = null;
    this.players.forEach((p) => { p.score = 0; p.stats = { agentRounds: 0, escapes: 0, correctVotes: 0, votes: 0 }; });
    this.nextRound();
    return null;
  }

  nextRound() {
    this.round += 1;
    const pool = this.active();
    let candidates = pool.filter((p) => !this.pastAgents.has(p.id));
    if (!candidates.length) { this.pastAgents.clear(); candidates = pool; }
    const agent = pick(candidates);
    this.agentId = agent.id;
    this.pastAgents.add(agent.id);
    agent.stats.agentRounds += 1;
    const all = resolveQuestions(this.settings.deckId, this.settings.customQuestions);
    let fresh = all.filter((q) => !this.usedQuestions.has(q));
    if (!fresh.length) { this.usedQuestions.clear(); fresh = all; }
    this.question = pick(fresh);
    this.usedQuestions.add(this.question);
    this.answers = new Map();
    this.votes = new Map();
    this.cards = [];
    this.result = null;
    this.setPhase('PROMPT');
  }

  buildCards() {
    this.cards = shuffle([...this.answers.entries()]).map(([authorId, text], id) => ({ id, text, authorId, laughs: 0, round: this.round }));
  }

  submitAnswer(pid, text) {
    if (this.phase !== 'ANSWER' || !this.players.has(pid) || this.answers.has(pid)) return;
    const t = clean(text, 120);
    if (!t) return;
    this.answers.set(pid, t);
    this.changed();
    this.checkCompletion();
  }

  castVote(pid, targetId) {
    if (this.phase !== 'VOTE' || !this.players.has(pid) || !this.players.has(targetId) || pid === targetId || this.votes.has(pid)) return;
    this.votes.set(pid, targetId);
    this.changed();
    this.checkCompletion();
  }

  checkCompletion() {
    const act = this.active();
    if (!act.length) return;
    if (this.phase === 'ANSWER' && act.every((p) => this.answers.has(p.id))) this.advance();
    else if (this.phase === 'VOTE' && act.every((p) => this.votes.has(p.id))) this.advance();
  }

  score() {
    const tally = {};
    this.votes.forEach((t) => { tally[t] = (tally[t] || 0) + 1; });
    const max = Math.max(0, ...Object.values(tally));
    const top = Object.keys(tally).filter((id) => tally[id] === max);
    const caught = max > 0 && top.length === 1 && top[0] === this.agentId; // ties favour the agent
    const gains = {};
    const agent = this.players.get(this.agentId);
    if (!caught && agent) { agent.score += POINTS.agentEscapes; agent.stats.escapes += 1; gains[agent.id] = POINTS.agentEscapes; }
    this.votes.forEach((target, voter) => {
      const p = this.players.get(voter);
      if (!p || voter === this.agentId) return;
      p.stats.votes += 1;
      if (target === this.agentId) { p.score += POINTS.correctVote; p.stats.correctVotes += 1; gains[voter] = POINTS.correctVote; }
    });
    this.result = { caught, tally, agentId: this.agentId, gains };
    this.cardHistory.push(...this.cards);
  }

  finish() {
    const ranked = [...this.players.values()].sort((a, b) => b.score - a.score);
    const funniest = [...this.cardHistory].sort((a, b) => b.laughs - a.laughs)[0];
    const sneaky = [...this.players.values()].sort((a, b) => b.stats.escapes - a.stats.escapes || b.score - a.score)[0];
    this.recap = {
      mvpId: ranked[0]?.id,
      funniest: funniest && funniest.laughs > 0 ? { text: funniest.text, authorId: funniest.authorId, laughs: funniest.laughs } : null,
      sneakyId: sneaky && sneaky.stats.escapes > 0 ? sneaky.id : null,
    };
    this.setPhase('FINAL');
  }

  hostSkip(pid) {
    if (!this.isHost(pid)) return;
    if (['DEBATE', 'REVEAL', 'SCOREBOARD'].includes(this.phase)) this.advance();
  }

  backToLobby(pid) {
    if (!this.isHost(pid) || this.phase !== 'FINAL') return;
    this.players.forEach((p, id) => { if (!p.isBot && !p.connected) this.players.delete(id); });
    this.setPhase('LOBBY');
  }

  updateSettings(pid, s) {
    if (!this.isHost(pid) || this.phase !== 'LOBBY') return;
    if (typeof s.deckId === 'string') this.settings.deckId = clean(s.deckId, 20);
    if (Number.isInteger(s.rounds)) this.settings.rounds = Math.min(15, Math.max(1, s.rounds));
    if (Array.isArray(s.customQuestions)) this.settings.customQuestions = s.customQuestions.map((q) => clean(q, 140)).filter(Boolean).slice(0, 60);
    this.changed();
  }

  addBot(pid) {
    if (!this.isHost(pid) || this.phase !== 'LOBBY') return;
    const used = new Set([...this.players.values()].map((p) => p.name));
    const name = BOT_NAMES.find((n) => !used.has(n + ' 🤖'));
    if (!name) return;
    this.addPlayer({ name: name + ' 🤖', avatar: pick(['🤖', '👾', '🦊', '🐼']), color: '#06b6d4', isBot: true });
  }

  removeBots(pid) {
    if (!this.isHost(pid) || this.phase !== 'LOBBY') return;
    this.players.forEach((p, id) => { if (p.isBot) this.players.delete(id); });
    this.changed();
  }

  scheduleBots(kind) {
    this.players.forEach((p) => {
      if (!p.isBot) return;
      this.botTimers.push(setTimeout(() => {
        if (kind === 'answer') this.submitAnswer(p.id, pick(BOT_ANSWERS));
        else this.castVote(p.id, pick([...this.players.values()].filter((o) => o.id !== p.id)).id);
      }, (1500 + Math.random() * 3000) * SCALE));
    });
  }

  // ---------- social ----------
  addChat(pid, text) {
    const p = this.players.get(pid);
    const t = clean(text, 200);
    if (!p || !t || !['LOBBY', 'SCOREBOARD', 'FINAL'].includes(this.phase)) return;
    this.chat.push({ id: newId(), from: p.name, avatar: p.avatar, text: t, at: Date.now() });
    this.chat = this.chat.slice(-50);
    this.changed();
  }

  react(pid, emoji, cardId) {
    const allowed = ['😂', '😱', '🔥', '👏', '🤔', '🕵️'];
    if (!this.players.has(pid) || !allowed.includes(emoji) || !['DEBATE', 'VOTE', 'REVEAL'].includes(this.phase)) return;
    const card = this.cards.find((c) => c.id === cardId);
    if (card && emoji === '😂') card.laughs += 1;
    this.hooks.fx(this, 'reaction', { emoji, playerId: pid, cardId: card ? card.id : null });
    if (card && this.phase === 'REVEAL') this.changed();
  }

  // ---------- views (server decides what each client may know) ----------
  /** @param {string|null} viewerId null = shared TV screen */
  view(viewerId) {
    const isTv = viewerId === null;
    const me = viewerId ? this.players.get(viewerId) : null;
    const inRound = PHASE_ORDER.indexOf(this.phase) >= 1 && this.phase !== 'FINAL';
    const revealed = ['REVEAL', 'SCOREBOARD', 'FINAL'].includes(this.phase);
    const youAreAgent = !!me && me.id === this.agentId && inRound;
    const canSeeQuestion = inRound && (revealed || (!isTv && !youAreAgent));
    const pub = (p) => ({ id: p.id, name: p.name, avatar: p.avatar, color: p.color, score: p.score, connected: p.connected, isBot: p.isBot, isHost: p.id === this.hostId });
    return {
      now: Date.now(), code: this.code, phase: this.phase, round: this.round, rounds: this.settings.rounds,
      deadline: this.deadline, duration: this.duration, settings: this.settings, hostId: this.hostId, youId: viewerId, isTv,
      youAreAgent, question: canSeeQuestion ? this.question : null,
      players: [...this.players.values()].map(pub),
      answeredIds: this.phase === 'ANSWER' ? [...this.answers.keys()] : [],
      votedIds: this.phase === 'VOTE' ? [...this.votes.keys()] : [],
      yourVote: viewerId ? this.votes.get(viewerId) || null : null,
      yourAnswered: viewerId ? this.answers.has(viewerId) : false,
      cards: ['DEBATE', 'VOTE', 'REVEAL', 'SCOREBOARD'].includes(this.phase)
        ? this.cards.map((c) => ({ id: c.id, text: c.text, laughs: c.laughs, authorId: revealed ? c.authorId : undefined })) : [],
      result: revealed && this.phase !== 'FINAL' ? { ...this.result, votes: Object.fromEntries(this.votes) } : null,
      recap: this.phase === 'FINAL' ? this.recap : null,
      chat: this.chat,
    };
  }

  destroy() { clearTimeout(this.timer); this.botTimers.forEach(clearTimeout); }
}

module.exports = { Room, makeCode, MIN_PLAYERS, MAX_PLAYERS, clean };
