'use strict';
const path = require('path');
const http = require('http');
const express = require('express');
const { Server } = require('socket.io');
const { Room, makeCode, clean } = require('./game');
const { router: api, userFromToken } = require('./auth');

const PORT = process.env.PORT || 3000;
const ORIGINS = process.env.CORS_ORIGINS ? process.env.CORS_ORIGINS.split(',') : true;
const GRACE_MS = 10 * 60 * 1000; // empty rooms live 10 min, so reconnecting players always find their game

const app = express();
app.set('trust proxy', 1);
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: ORIGINS }, pingInterval: 10000, pingTimeout: 8000, maxHttpBufferSize: 64 * 1024 });

app.disable('x-powered-by');
app.use((_q, res, next) => { res.set({ 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'same-origin' }); next(); });
app.get('/healthz', (_q, r) => r.json({ ok: true, rooms: rooms.size }));
app.use('/api', api);
app.use(express.static(path.join(__dirname, '..', 'public')));
app.get(['/tv', '/join/:code'], (_q, r) => r.sendFile(path.join(__dirname, '..', 'public', 'index.html')));

/** @type {Map<string, Room>} */ const rooms = new Map();
/** session token -> { code, playerId|null, role:'player'|'tv' }  (swap for Redis when scaling horizontally) */
const sessions = new Map();

const hooks = {
  broadcast(room) {
    room.players.forEach((p) => { if (p.connected && p.socketId) io.to(p.socketId).emit('state', room.view(p.id)); });
    io.to('tv:' + room.code).emit('state', room.view(null));
  },
  fx(room, ev, data) { io.to('room:' + room.code).emit(ev, data); },
};

/** Tiny per-socket rate limiter. */
function limiter(max, perMs) {
  let n = 0, t = Date.now();
  return () => { if (Date.now() - t > perMs) { n = 0; t = Date.now(); } return ++n <= max; };
}

io.use((socket, next) => { socket.data.user = userFromToken(socket.handshake.auth?.jwt); next(); });

io.on('connection', (socket) => {
  const ok = limiter(30, 5000);
  const react = limiter(6, 2000);
  const ctx = () => {
    const s = sessions.get(socket.data.token);
    const room = s && rooms.get(s.code);
    return room ? { s, room } : null;
  };

  function attach(room, role, player) {
    const token = player ? player.token : 'tv_' + Math.random().toString(36).slice(2) + Date.now().toString(36);
    sessions.set(token, { code: room.code, playerId: player ? player.id : null, role });
    socket.data.token = token;
    socket.join('room:' + room.code);
    if (role === 'tv') socket.join('tv:' + room.code);
    return token;
  }

  socket.on('room:create', ({ name, avatar, color, mode } = {}, ack = () => {}) => {
    if (!ok()) return ack({ error: 'slow down' });
    const room = new Room(makeCode(rooms), hooks);
    rooms.set(room.code, room);
    try {
      if (mode === 'tv') {
        const token = attach(room, 'tv');
        socket.emit('state', room.view(null));
        return ack({ ok: true, token, code: room.code, role: 'tv' });
      }
      const p = room.addPlayer({ name: name || socket.data.user?.name, avatar, color, userId: socket.data.user?.id });
      room.setConnected(p.id, true, socket.id);
      const token = attach(room, 'player', p);
      return ack({ ok: true, token, code: room.code, playerId: p.id, role: 'player' });
    } catch (e) { rooms.delete(room.code); return ack({ error: e.message }); }
  });

  socket.on('room:join', ({ code, name, avatar, color } = {}, ack = () => {}) => {
    if (!ok()) return ack({ error: 'slow down' });
    const room = rooms.get(clean(code, 5).toUpperCase());
    if (!room) return ack({ error: 'الغرفة غير موجودة' });
    try {
      const p = room.addPlayer({ name: name || socket.data.user?.name, avatar, color, userId: socket.data.user?.id });
      room.setConnected(p.id, true, socket.id);
      const token = attach(room, 'player', p);
      ack({ ok: true, token, code: room.code, playerId: p.id, role: 'player' });
    } catch (e) { ack({ error: e.message }); }
  });

  // Seamless reconnection: same token -> same player, same score, current phase.
  socket.on('session:resume', ({ token } = {}, ack = () => {}) => {
    const s = sessions.get(token);
    const room = s && rooms.get(s.code);
    if (!room) return ack({ error: 'expired' });
    socket.data.token = token;
    socket.join('room:' + room.code);
    if (s.role === 'tv') { socket.join('tv:' + room.code); socket.emit('state', room.view(null)); return ack({ ok: true, role: 'tv', code: room.code }); }
    const p = room.players.get(s.playerId);
    if (!p) { sessions.delete(token); return ack({ error: 'expired' }); }
    if (p.socketId && p.socketId !== socket.id) io.to(p.socketId).emit('session:replaced'); // same player opened a second tab
    room.setConnected(p.id, true, socket.id);
    return ack({ ok: true, role: 'player', code: room.code, playerId: p.id });
  });

  const withPlayer = (fn) => (data) => {
    if (!ok()) return;
    const c = ctx();
    if (c && c.s.playerId) fn(c.room, c.s.playerId, data || {}, c);
  };

  socket.on('game:start', withPlayer((room, pid) => { const err = room.startGame(pid); if (err) socket.emit('toast', err); }));
  socket.on('game:skip', withPlayer((room, pid) => room.hostSkip(pid)));
  socket.on('game:lobby', withPlayer((room, pid) => room.backToLobby(pid)));
  socket.on('lobby:settings', withPlayer((room, pid, d) => room.updateSettings(pid, d)));
  socket.on('lobby:addBot', withPlayer((room, pid) => room.addBot(pid)));
  socket.on('lobby:removeBots', withPlayer((room, pid) => room.removeBots(pid)));
  socket.on('answer:submit', withPlayer((room, pid, d) => room.submitAnswer(pid, d.text)));
  socket.on('vote:cast', withPlayer((room, pid, d) => room.castVote(pid, d.targetId)));
  socket.on('chat:send', withPlayer((room, pid, d) => room.addChat(pid, d.text)));
  socket.on('react:send', (d = {}) => { const c = ctx(); if (c && c.s.playerId && react()) c.room.react(c.s.playerId, d.emoji, d.cardId); });

  socket.on('disconnect', () => {
    const c = ctx();
    if (c && c.s.playerId) {
      const p = c.room.players.get(c.s.playerId);
      if (p && p.socketId === socket.id) c.room.setConnected(p.id, false);
    }
  });
});

// Sweep abandoned rooms and their sessions.
setInterval(() => {
  rooms.forEach((room, code) => {
    const anyone = room.active().some((p) => !p.isBot) || (io.sockets.adapter.rooms.get('tv:' + code)?.size || 0) > 0;
    if (!anyone && Date.now() - room.touched > GRACE_MS) {
      room.destroy(); rooms.delete(code);
      sessions.forEach((s, t) => { if (s.code === code) sessions.delete(t); });
    }
  });
}, 60 * 1000).unref();

if (require.main === module) server.listen(PORT, () => console.log(`Agent Under Suspicion on :${PORT} — Developed by Youssef Ibrahim`));
module.exports = { server, io, rooms };
