'use strict';
const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const { listDecks } = require('./decks');

const isProd = process.env.NODE_ENV === 'production';
if (isProd && !process.env.JWT_SECRET) throw new Error('JWT_SECRET must be set in production');
const SECRET = process.env.JWT_SECRET || 'dev-only-secret';

/**
 * Repository interface. This in-memory implementation is the only part you
 * swap for Prisma (see prisma/schema.prisma) — the routes never touch storage directly.
 */
const db = {
  users: new Map(),   // id -> user
  decks: new Map(),   // id -> deck
  byEmail(e) { return [...this.users.values()].find((u) => u.email === e); },
};

const sign = (u) => jwt.sign({ sub: u.id, guest: !!u.guest }, SECRET, { expiresIn: '30d' });
const publicUser = (u) => ({ id: u.id, name: u.name, email: u.email || null, guest: !!u.guest, tag: u.tag, avatar: u.avatar || null, stats: u.stats });
const newTag = () => '#' + crypto.randomInt(1000, 9999);
const mkUser = (o) => { const u = { id: crypto.randomUUID(), tag: newTag(), stats: { games: 0, wins: 0, agentGames: 0, agentWins: 0 }, ...o }; db.users.set(u.id, u); return u; };

/** Express middleware: attaches req.user when a valid Bearer token is present. */
function requireUser(req, res, next) {
  try {
    const t = (req.headers.authorization || '').replace('Bearer ', '');
    const p = jwt.verify(t, SECRET);
    req.user = db.users.get(p.sub);
    if (!req.user) throw new Error('no user');
    next();
  } catch { res.status(401).json({ error: 'unauthorized' }); }
}

/** Resolve a JWT to a user (used by the socket layer). */
function userFromToken(t) {
  try { return db.users.get(jwt.verify(t, SECRET).sub) || null; } catch { return null; }
}

const router = express.Router();
router.use(express.json({ limit: '50kb' }));

router.get('/config', (_q, r) => r.json({ googleClientId: process.env.GOOGLE_CLIENT_ID || null }));

router.post('/auth/guest', (req, res) => {
  const u = mkUser({ name: String(req.body.name || 'ضيف').slice(0, 16), guest: true });
  res.json({ token: sign(u), user: publicUser(u) });
});

router.post('/auth/register', async (req, res) => {
  const { email, password, name } = req.body || {};
  if (!/^\S+@\S+\.\S+$/.test(email || '') || String(password || '').length < 8) return res.status(400).json({ error: 'بيانات غير صالحة (كلمة المرور 8 أحرف على الأقل)' });
  const mail = email.toLowerCase();
  const hash = await bcrypt.hash(password, 10);
  // Guest -> account conversion: keep the same user id, stats and tag.
  let existing = null;
  try { existing = db.users.get(jwt.verify((req.headers.authorization || '').replace('Bearer ', ''), SECRET).sub); } catch { /* not logged in */ }
  if (db.byEmail(mail)) return res.status(409).json({ error: 'البريد مستخدم بالفعل' });
  const u = existing && existing.guest ? Object.assign(existing, { email: mail, hash, guest: false, name: name || existing.name }) : mkUser({ email: mail, hash, name: name || mail.split('@')[0] });
  res.json({ token: sign(u), user: publicUser(u) });
});

router.post('/auth/login', async (req, res) => {
  const u = db.byEmail(String(req.body?.email || '').toLowerCase());
  if (!u || !u.hash || !(await bcrypt.compare(String(req.body.password || ''), u.hash))) return res.status(401).json({ error: 'بيانات الدخول غير صحيحة' });
  res.json({ token: sign(u), user: publicUser(u) });
});

// Google One Tap: verify the ID token with Google, then upsert the user.
router.post('/auth/google', async (req, res) => {
  try {
    const r = await fetch('https://oauth2.googleapis.com/tokeninfo?id_token=' + encodeURIComponent(req.body.credential));
    const g = await r.json();
    if (!r.ok || g.aud !== process.env.GOOGLE_CLIENT_ID || g.email_verified !== 'true') throw new Error('bad token');
    const u = db.byEmail(g.email.toLowerCase()) || mkUser({ email: g.email.toLowerCase(), name: g.given_name || g.name, avatar: null });
    res.json({ token: sign(u), user: publicUser(u) });
  } catch { res.status(401).json({ error: 'Google sign-in failed' }); }
});

router.get('/me', requireUser, (req, res) => res.json({ user: publicUser(req.user) }));

// Decks
router.get('/decks', (_q, r) => r.json({ builtin: listDecks() }));
router.get('/decks/mine', requireUser, (req, res) => res.json({ decks: [...db.decks.values()].filter((d) => d.ownerId === req.user.id) }));
router.post('/decks', requireUser, (req, res) => {
  const questions = (Array.isArray(req.body.questions) ? req.body.questions : []).map((q) => String(q).trim().slice(0, 140)).filter(Boolean).slice(0, 60);
  if (questions.length < 3) return res.status(400).json({ error: 'أضف 3 أسئلة على الأقل' });
  const d = { id: crypto.randomUUID(), ownerId: req.user.id, name: String(req.body.name || 'مجموعتي').slice(0, 30), questions, isPublic: !!req.body.isPublic };
  db.decks.set(d.id, d);
  res.json({ deck: d });
});
router.delete('/decks/:id', requireUser, (req, res) => {
  const d = db.decks.get(req.params.id);
  if (!d || d.ownerId !== req.user.id) return res.status(404).json({ error: 'not found' });
  db.decks.delete(d.id);
  res.json({ ok: true });
});

module.exports = { router, userFromToken, db };
