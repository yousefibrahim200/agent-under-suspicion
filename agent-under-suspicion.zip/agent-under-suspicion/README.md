# عميل فوق الشبهات — Agent Under Suspicion
Real-time multiplayer party game. **Developed by Youssef Ibrahim**

## Run
```bash
npm install
npm start            # http://localhost:3000
npm test             # end-to-end socket test: TV + 3 phones, secrecy, reconnect, scoring
```
- **Phones:** open `/` → create or join a room (or scan the QR / open `/join/ABCDE`).
- **TV / laptop screen:** open `/tv`. It creates a room and shows the code + QR. Phones are the controllers.

## Structure
```
server/
  index.js        Express + Socket.io: rooms, sessions, resume, rate limiting, room sweeper
  game.js         Room class = authoritative state machine (LOBBY→PROMPT→ANSWER→DEBATE→VOTE→REVEAL→SCOREBOARD→FINAL)
  decks.js        5 built-in Arabic decks + resolver for custom decks
  auth.js         JWT email/password, guest, guest→account upgrade, Google ID-token login, deck CRUD
  smoke.test.js   integration test
public/
  index.html      phone controller + TV display (one file, no build step)
  vendor/qrcode.js
prisma/schema.prisma   PostgreSQL schema (users, decks, friends, games, badges)
```

## Design decisions
- **Server is authoritative.** Clients only send intents (`answer:submit`, `vote:cast`…). Timers live on the server.
- **Information hiding is enforced server-side.** `Room.view(playerId)` builds a per-player view: the agent's view never contains the question, the TV never receives it until REVEAL, and card authors are stripped until REVEAL.
- **Reconnection.** Every player gets a session token (stored in `localStorage`). On any reconnect the client sends `session:resume`; the server rebinds the socket to the same player and pushes the current phase. Lobby seats are held for 30 s, rooms for 10 min after everyone leaves. Host migrates automatically.
- **Rules (unchanged from your original):** +100 for a correct vote, +200 for the agent if not caught. Ties favour the agent.

## Deploy
Socket.io needs a **long-running Node process**.
- **Render / Railway / Fly:** works as-is (`render.yaml` included). Set `JWT_SECRET`.
- **Vercel:** serverless functions cannot hold WebSocket connections, so the backend cannot run there. You may host `public/` on Vercel and the server on Render/Railway — set `CORS_ORIGINS` and point the client's `io()` at the server URL.
- **Scaling beyond one instance:** move `rooms`/`sessions` to Redis and add `@socket.io/redis-adapter` (or enable sticky sessions and keep one instance per room).

## Not done yet (honest status)
- **Persistence:** `auth.js` uses an in-memory repo, so accounts/decks reset on restart. `prisma/schema.prisma` is ready; swap the `db` object for Prisma calls.
- **Friends system, presence, party invites, badges/neon-frame unlocks, player dashboard:** schema exists; no endpoints or UI yet.
- **Avatar upload:** camera/gallery with automatic centre-crop + compression to 96 px. There is no interactive crop UI.
- **UI stack:** vanilla JS + hand-written CSS instead of React/Framer Motion/Tailwind (keeps it one deployable file). Porting to Next.js is straightforward since all logic is behind the socket events.
- **Typing:** plain JavaScript with JSDoc types, not TypeScript.
- **Lobby chat** only (plus emoji reactions during debate/vote/reveal); no sound reactions yet.
